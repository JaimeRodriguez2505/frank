import CsrfCookieController from './CsrfCookieController'

const Controllers = {
    CsrfCookieController: Object.assign(CsrfCookieController, CsrfCookieController),
}

export default Controllers